import azure.functions as func
import logging

app = func.FunctionApp()


@app.function_name(name="iot_hub_trigger")
@app.event_hub_message_trigger(
    arg_name="event",
    event_hub_name="iothub-ehub",
    connection="IOTHUB_CONNECTION"
)
@app.blob_output(
    arg_name="outputBlob",
    path="iot-data/{rand-guid}.json",
    connection="AzureWebJobsStorage"
)
def iot_hub_trigger(event: func.EventHubEvent, outputBlob: func.Out[str]):

    msg = event.get_body().decode()
    logging.info(f"IoT Hub message received: {msg}")

    # Save to Blob
    outputBlob.set(msg)
